        function bodyBGGreen()
        {
            document.body.style.backgroundColor="Green";
        }
        function divBGGray()
        {
            document.getElementById("D1").style.backgroundColor="Gray";
        }

        function bodyBGDynamic()
        {
            document.body.style.backgroundColor=prompt("enter color name");
        }
        function divBGDynamic()
        {
            document.getElementById("D1").style.backgroundColor=prompt("enter color name");
        }

        function bodyCP1()
        {
            document.body.style.backgroundColor = document.getElementById("CP1").value;
        }
        function divCP2()
        {
            document.getElementById("D1").style.backgroundColor = document.getElementById("CP2").value;
        }

        function demo1()
        {
            var a=prompt("enter Number1");
            var b=prompt("enter Number2");
            if(a>b)
            {
                alert(a+" is grater");
            }
            else
            {
                alert(b+" is grater");
            }
        }
        function demo2()
        {
            var r=prompt("enter the radius for circle");
            var area;
            area=3.14*r*r;
            alert("Area of Circle is "+" "+area);
        }