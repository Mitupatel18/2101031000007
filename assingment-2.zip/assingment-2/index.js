
$(document).ready(function() {
    $('#feedbackForm').submit(function(event) {
      event.preventDefault();
      var $FullNameRegEx = /^([a-zA-Z]{2,40})$/;
      var $EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;
      var $ConNoRegEx = /^([0-9]{10})$/;
      

      // Validation
    $("#name").blur(function(){
        $("#TxtNameValidation").empty();
            if($(this).val()=="" || $(this).val()==null){
                $("#TxtNameValidation").html("(*) Name required..!!");
            }
            else{
                if(!$(this).val().match($FullNameRegEx)){
                    $("#TxtNameValidation").html("(*) Invalid name..!!");
                }
            }
        });
        $("#name").keypress(function(e){
            $("#TxtNameValidation").empty();
            var Flag=((e.which>=65 && e.which<=90) || (e.which>=97 && e.which<=121));
                if(Flag==false){
                     $("#TxtNameValidation").html("Invalid Input..!!");
                }
                return Flag;
            });



    $("#email").blur(function(){
		$("#TxtEmailIdValidation").empty();
			if($(this).val()=="" || $(this).val()==null){
				$("#TxtEmailIdValidation").html("(*) Email id required..!!");
			}
			else{
				if(!$(this).val().match($EmailIdRegEx)){
					$("#TxtEmailIdValidation").html("(*) Invalid email id..!!");
				}
			}
		});



    $("#number").blur(function(){
        $("#TxtContactNoValidation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#TxtContactNoValidation").html("(*) Contact no. required..!!");
        }
        else{
            if(!$(this).val().match($ConNoRegEx)){
                $("#TxtContactNoValidation").html("(*) Invalid contact no..!!");
            }
        }
    });
    $("#number").keypress(function(e){
        $("#TxtContactNoValidation").empty();
        var Flag=(e.which>=48 && e.which<=57);
        if(Flag==false){
            $("#TxtContactNoValidation").html("Invalid Input..!!");
        }
        return Flag;
    });



    $("#fedback").blur(function(){
        $("#TxtfeedbackValidation").empty();
            if($(this).val()=="" || $(this).val()==null){
                $("#TxtfeedValidation").html("(*) Feedback required..!!");
            }
        });

        $("#BtnSubmit").click(function(){
            $("#name").blur(function(){
                $("#TxtNameValidation").empty();
                    if($(this).val()=="" || $(this).val()==null){
                        $("#TxtNameValidation").html("(*) Name required..!!");
                    }
                    else{
                        if(!$(this).val().match($FullNameRegEx)){
                            $("#TxtNameValidation").html("(*) Invalid name..!!");
                        }
                    }
            });
            $("#name").keypress(function(e){
                $("#TxtNameValidation").empty();
                var Flag=((e.which>=65 && e.which<=90) || (e.which>=97 && e.which<=121));
                    if(Flag==false){
                         $("#TxtNameValidation").html("Invalid Input..!!");
                    }
                    return Flag;
            });
        
        
        
            $("#email").blur(function(){
                $("#TxtEmailIdValidation").empty();
                    if($(this).val()=="" || $(this).val()==null){
                        $("#TxtEmailIdValidation").html("(*) Email id required..!!");
                    }
                    else{
                        if(!$(this).val().match($EmailIdRegEx)){
                            $("#TxtEmailIdValidation").html("(*) Invalid email id..!!");
                        }
                    }
            });
        
        
        
            $("#number").blur(function(){
                $("#TxtContactNoValidation").empty();
                if($(this).val()=="" || $(this).val()==null){
                    $("#TxtContactNoValidation").html("(*) Contact no. required..!!");
                }
                else{
                    if(!$(this).val().match($ConNoRegEx)){
                        $("#TxtContactNoValidation").html("(*) Invalid contact no..!!");
                    }
                }
            });
            $("#number").keypress(function(e){
                $("#TxtContactNoValidation").empty();
                var Flag=(e.which>=48 && e.which<=57);
                if(Flag==false){
                    $("#TxtContactNoValidation").html("Invalid Input..!!");
                }
                return Flag;
            });
        
        
        
            $("#fedback").blur(function(){
                $("#TxtfeedbackValidation").empty();
                    if($(this).val()=="" || $(this).val()==null){
                        $("#TxtfeedValidation").html("(*) Feedback required..!!");
                    }
            });
        });
    });
});
