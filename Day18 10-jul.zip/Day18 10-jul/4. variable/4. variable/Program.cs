﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.variable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int myNum = 10;               // integer (whole number)
            double myDoubleNum = 4.36D;  // floating point number
            char myLetter = 'j';         // character
            bool myBool = true;          // boolean
            string myText = "Hello";

            Console.WriteLine(myNum);
            Console.WriteLine(myDoubleNum);
            Console.WriteLine(myLetter);
            Console.WriteLine(myBool);
            Console.WriteLine(myText);
            Console.ReadKey();
        }
    }
}
