﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace secend_project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name = "Mit";
            Console.WriteLine(name);
            Console.WriteLine("Hello " + name);
            Console.Write($"Hello {name}");
            Console.ReadKey();
        }
    }
}
