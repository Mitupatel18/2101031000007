﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace For_Lop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter 4 digit password: ");
            int a = Convert.ToInt32(Console.ReadLine());

            for (int i = 1000; i <= a; i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
