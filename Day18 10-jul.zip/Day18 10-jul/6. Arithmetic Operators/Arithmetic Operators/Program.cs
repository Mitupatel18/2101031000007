﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arithmetic_Operators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 6;

            Console.WriteLine(a + b);
            Console.WriteLine(a - b);
            Console.WriteLine(a * b);
            Console.WriteLine(a / b);
            Console.WriteLine(a % b);
            Console.WriteLine(++a);
            Console.WriteLine(--b);
            Console.ReadKey();
        }
    }
}
