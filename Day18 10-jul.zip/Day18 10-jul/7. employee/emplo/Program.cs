﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emplo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the employee details");
            Console.WriteLine("Enetr Employee ID");
            int empid =Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Enter Name");
            String name = (Console.ReadLine());
            Console.WriteLine("Enetr salary");
            int sal =Convert.ToInt32 (Console.ReadLine());
            Console.WriteLine("Enter Deparment");
            String dep = (Console.ReadLine());

            Console.WriteLine("Employee ID is: " + empid);
            Console.WriteLine("Employee Name is: " + name);
            Console.WriteLine("Employee Salary is: " + sal);
            Console.WriteLine("Employee Deparment is: " + dep);
            Console.ReadKey();
        }
    }
}
