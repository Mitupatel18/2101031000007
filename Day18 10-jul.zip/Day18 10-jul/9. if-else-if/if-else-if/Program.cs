﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace if_else_if
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter No.(1 or 2): ");
            int a = Convert.ToInt32( Console.ReadLine());

            if (a == 1)
            {
                Console.WriteLine("Hello");
            }
            else if (a == 2)
            {
                Console.WriteLine("Hey");
            }
            else
            {
                Console.WriteLine("Not valid No.");
            }
            Console.ReadKey();
        }
    }
}
