<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $a=15;
    $b=20;

    if($a>$b){
        echo $a." is grater";
    }else{
        echo $b." is grater";
    }
    ?>
</body>
</html>