<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $a = 10;
    $b = 5;
    $add=$a+$b;
    $sub=$a-$b;
    $multi=$a*$b;
    $div=$a/$b;
    echo "a is: ".$a."<br>";
    echo "b is: ".$b."<br>";
    echo "a + b: ".$add."<br>";
    echo "a - b: ".$sub."<br>";
    echo "a * b: ".$multi."<br>";
    echo "a / b: ".$div."<br>";
    ?>
</body>
</html>