<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $a = 2;
    $i = 1;
    $b;
    while($i<=10)
    {
        $b=$a*$i;
        echo $a." * ".$i." = ".$b."<br>";
        $i++;
    }
    ?>
</body>
</html>