<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $a=20;
    $b=10;
    $c=22;

    if($a>$b && $a>$c)
    {
        echo $a." is grater"; 
    }elseif($b>$c)
    {
        echo $b." is gtater";
    }else
    {
        echo $c." is grater";
    }
    ?>
</body>
</html>