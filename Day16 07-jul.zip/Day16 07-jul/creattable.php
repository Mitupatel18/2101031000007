<?php 
$username="root";
$servername="localhost";
$password="";
$dbname="myDB";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die ("Connection Failed".mysqli_connect_error());
}
$sql="CREATE TABLE Table1 (ID int AUTO_INCREMENT, Username varchar(20), Passwords varchar(10), PRIMARY KEY (ID))";
if(mysqli_query($conn, $sql))
{
    echo "table created";
}
else
{
    echo "error".mysqli_error($conn);
}
mysqli_close($conn);
?>