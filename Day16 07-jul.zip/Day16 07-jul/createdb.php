<?php 
$username="root";
$servername="localhost";
$password="";
$dbname="myDB";
$conn=mysqli_connect($servername,$username,$password);
if(!$conn)
{
    die ("Connection Failed".mysqli_connect_error());
}
$sql="create database myDB";
if(mysqli_query($conn,$sql))
{
    echo "database created";
}
else
{
    echo "error";
}
?>