<?php
$username = "root";
$servername = "localhost";
$password = "";
$dbname = "myDB";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Insert vlues in table(database).
$username = "Meet";
$password = "5482";

$sql = "INSERT INTO Table1 (username, passwords)
        VALUES ('$username', '$password')";

if (mysqli_query($conn, $sql)) {
    echo "Record inserted successfully";
} else {
    echo "Error inserting record: " . mysqli_error($conn);
}

mysqli_close($conn);
?>