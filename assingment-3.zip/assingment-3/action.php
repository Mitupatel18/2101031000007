<?php
$username = "root";
$servername = "localhost";
$password = "";
$dbname = "feedback";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Insert vlues in table(database).
$name = $_POST['name'];
$email = $_POST['email'];
$contect = $_POST['number'];
$feedback = $_POST['feedback'];

$sql = "INSERT INTO feedback_table1 (name, email, contect, feedback)
        VALUES ('$name', '$email', '$contect', '$feedback')";

if (mysqli_query($conn, $sql)) {
    echo "Submit successfully.";
} else {
    echo "Not Submit Successfully !: " . mysqli_error($conn);
}

mysqli_close($conn);
?>