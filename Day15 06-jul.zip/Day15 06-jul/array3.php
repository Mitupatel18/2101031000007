<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array3</title>
</head>
<body>
 <?php
       $a = array("nikhil","gaurav","keyur","harsh");
       $b = array("dhruvin","mit");
     print_r(array_merge($a,$b));  
   
    ?>
</body>
</html>