<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array4</title>
</head>
<body>
 <?php
       $a = array("nikhil","gaurav","keyur","harsh");
      print_r($a);
      echo "<br>";
      echo "<br>";

      echo "reversed array is:-"."<br>";
      print_r(array_reverse($a));
      echo "<br>";
      echo "<br>";
      echo "count of array is:-"."<br>";

      echo (count($a));
   
    ?>
</body>
</html>