<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array6</title>
</head>
<body>
   
 <?php
       $a = 250;
       echo $a."<br>";
       echo abs($a)."<br>";
       echo pow(3,3)."<br>";
       echo min(42,50,11,4)."<br>";
       $b = 25.428;
       echo ceil($b)."<br>";

    ?>
</body>
</html>